package com.mobdeve.yourname.exercise3lifecyclesp

enum class LayoutType {
    LINEAR_VIEW_TYPE, GRID_VIEW_TYPE
}